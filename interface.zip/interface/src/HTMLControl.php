<?php
require ('OptionsNotFoundException.php');
abstract class HTMLControl implements IControl {
    protected $name;
    protected $value;
    protected $label;
    protected $arrayOptions = [];


    
    public function __construct($name, $value, $label, $arrayOptions){

        try {
            if (empty($name))
                throw new Exception ( "Name buit.");
                $this->name=$name;
        }
        catch (Exception $e) {
            echo "S'ha produït el següent error:". $e-> getMessage();
        }


        $this->value = $value;
        $this->label = $label;

        try {
            if (empty($arrayOptions))
                throw new OptionsNotFoundException();
            $this->arrayOptions = $arrayOptions;
        }
        catch (OptionsNotFoundException $o) {
            echo "S'ha produït el següent error:". $o->getMessage();
        }

    }


    public function render():string{
        $html = '';
        $html .="<div>\n";
                $html .="\t<label> $this->label </label>\n";
                $html .="\t<select name=\" $this->name \">\n";
                $html .= "\t</select>\n";
                $html .="\t<input name=\" $this->name \" value=\"$this->value\"";
                $html .=" type=\"submit\"";
                $html .= "/>\n";

        $html .="</div>\n";
        return $html;
    }

}
