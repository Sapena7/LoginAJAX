<?php

interface IControl {
    public function render():string;
}

