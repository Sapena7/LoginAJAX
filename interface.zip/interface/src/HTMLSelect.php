<?php

class HTMLSelect extends HTMLControl implements IControl{



    public function render():string{
        $html = '';
        $html .="<div>\n";
        $html .="<select>";
        foreach ($this->arrayOptions as $opt) {
            $html .="\t\t<option value=\"{$opt['value']}\">";
            $html .="{$opt['name']}";
            $html .="</option>";
        }

        $html .= "/>\n";
        $html .="<label> $this->label </label>";
        $html .="</div>\n";
        return $html;
    }
}
