<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
require ('src/HTMLForm.php');
require ('src/HTMLControl.php');
require ('src/HTMLInputText.php');
require ('src/HTMLInputRadio.php');
require ('src/HTMLInputSubmit.php');
require ('src/HTMLSelect.php');

$form = new HTMLForm('testing.php', 'post');


$form->setAction('test.php');

$input = new HTMLInputText("","", "Search", "");
$form->add($input);

$input = new HTMLInputRadio("type", "song", "Song", "");
$form->add($input);

$input = new HTMLInputRadio("type","album", "Album", "");
$form->add($input);

$input = new HTMLInputRadio("type","all", "All","");
$form->add($input);

$input = new HTMLSelect("type","", "",[
        ["name" => "todos", "value" => "todos"],
        ["name" => "rock", "value" => "rock"],
        ["name" => "pop", "value" => "pop"],
        ["name" => "jazz", "value" => "jazz"],
        ["name" => "blues", "value" => "blues"]


]);

//[
//        ["name" => "todos", "value" => "todos"],
//        ["name" => "rock", "value" => "rock"],
//        ["name" => "pop", "value" => "pop"],
//        ["name" => "jazz", "value" => "jazz"],
//        ["name" => "blues", "value" => "blues"]
//
//
//]
$form->add($input);



$input = new HTMLInputSubmit("submit","Submit", "Submit","");
$form->add($input);

echo $form ->render();

echo "Total elementos: " . count($form);

?>

</body>
</html>
